package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class SampleController implements Initializable {
	@FXML
	private Label language;
	@FXML
	private Label currentDateTime;

	@FXML
	private TextArea textArea;

	@FXML
	private Button closeBtn;

	private Stage stage;
	@FXML
	private MenuItem about;

	@FXML
	private javafx.scene.control.MenuBar closeButton;

	@FXML
	public void exit_click(ActionEvent event) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("�޸���");
		alert.setHeaderText("���泻���� �����Ͻðڽ��ϱ�?");

		ButtonType buttonTypeOne = new ButtonType("����");
		ButtonType buttonTypeTwo = new ButtonType("�������");
		ButtonType buttonTypeThree = new ButtonType("���");

		alert.getButtonTypes().setAll(buttonTypeOne, buttonTypeTwo, buttonTypeThree);
		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == buttonTypeOne) {
			save_click(event);
		} else if (result.get() == buttonTypeTwo) {
			System.exit(0);
		} else if (result.get() == buttonTypeThree) {
			// ... user chose "Three"
		} else {
			// ... user chose CANCEL or closed the dialog
		}
	}

	@FXML
	public void open_click(ActionEvent event) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("���� ����");
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.txt"),
				new ExtensionFilter("All Files", "*.*"));
		File file = fileChooser.showOpenDialog(stage);
		getTextFromFile(file);
	}

	@FXML
	public void save_click(ActionEvent event) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("���� ����");
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.txt"),
				new ExtensionFilter("All Files", "*.*"));
		File file = fileChooser.showSaveDialog(stage);
		if (file != null) {
			saveFile(file);
		}

	}

	@FXML
	public void about_click(ActionEvent event) throws IOException {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("�޸��� ����");
		alert.setHeaderText("Windows 7 Professional K");
		alert.setContentText("Microsoft Windows \n���� 6.1 (���� 7601:Service Pack1)\nCopyright �� 2009 Microsoft Corporation, �����. All rights resevered.");

		alert.showAndWait();
	}

	public void getTextFromFile(File txtFile) {
		if (txtFile != null) {
			textArea.setText(readFile(txtFile));
		}
	}

	public String readFile(File file) {
		StringBuilder stringBuffer = new StringBuilder();
		BufferedReader bufferedReader = null;

		try {
			bufferedReader = new BufferedReader(new FileReader(file));
			String text;
			while ((text = bufferedReader.readLine()) != null) {
				stringBuffer.append(text + "\n");
			}
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return stringBuffer.toString();
	}

	public void saveFile(File file) {
		try {
			FileWriter writer = null;
			writer = new FileWriter(file);
			writer.write(textArea.getText().replaceAll("\n", "\r\n"));
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void changeFont(ActionEvent e) {
		System.out.println("������");
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		Thread thread = new Thread() {
			public void run() {
				while (true) {
					try {
						Date now = Calendar.getInstance().getTime();
						String s = MessageFormat.format("{0,date,yyyy-MM-dd HH:mm:ss}", now);
						Platform.runLater(() -> {
							currentDateTime.setText(s);
						});
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		thread.start();

		Thread check_thread = new Thread() {

			@Override
			public void run() {

				while (true) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

					String get_String = textArea.getText();

					if (!get_String.equals("")) {
						char lastChar = get_String.charAt(get_String.length() - 1);
						String last = Character.toString(lastChar);

						if (last.matches(".*[��-����-�Ӱ�-�R]+.*") == true) {
							Platform.runLater(() -> language.setText("�ѱ�"));
						} else if (last.matches(".*[a-z|A-Z]+.*") == true) {
							Platform.runLater(() -> language.setText("����"));
						}

					}

				}
			}

		};

		check_thread.start();
	}
}
